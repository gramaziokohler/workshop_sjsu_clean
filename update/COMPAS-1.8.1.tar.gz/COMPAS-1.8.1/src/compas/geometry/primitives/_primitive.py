from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from ..geometry import Geometry


class Primitive(Geometry):
    """Base class for geometric primitives."""
