
class DecoderError(Exception):
    pass
