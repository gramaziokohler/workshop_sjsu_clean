from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from compas.robots import Configuration

__all__ = [
    'Configuration',
]
