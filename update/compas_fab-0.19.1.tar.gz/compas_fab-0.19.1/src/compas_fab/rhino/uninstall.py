from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

if __name__ == "__main__":
    print('This uninstallation method is obsolete.')
    print('Please use `python -m compas_rhino.uninstall` instead')
